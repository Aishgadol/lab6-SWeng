select players.playername from players 
ORDER BY PlayerName desc;