select sum(wins) as total_hapoel_wins 
from teams
 where team like "%hapoel%";