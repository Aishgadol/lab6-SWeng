select teams.coach from teams
where coach like "%a%";